import java.applet.*;
import java.awt.*;

public class SqrCir extends Applet{
    public void paint(Graphics g){
        g.drawOval(150, 150, 100, 100);
        g.drawRect(100,100,200,200);
    }
}

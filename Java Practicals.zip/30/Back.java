import java.applet.Applet; 
import java.awt.Color; 
import java.awt.Graphics; 
public class Back extends Applet{
public void paint(Graphics g) {
setBackground(Color.red);
}
}
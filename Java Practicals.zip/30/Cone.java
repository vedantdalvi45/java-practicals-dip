import java.applet.*;
import java.awt.*;

public class Cone extends Applet{
    public void paint(Graphics g){
    g.drawOval(200,80,200,50);
    g.drawLine(200,100,300,500);
    g.drawLine(400,100,300,500);
    }
}

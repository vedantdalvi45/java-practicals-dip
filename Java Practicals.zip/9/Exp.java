class Exp {
    public static void main(String[] args) {
       double d = 87.0d;
       float f = (float)d;
       long l = (long)f;
       int i =(int)l;
       short s = (short)i;
       byte b = (byte)s;
       //double e =(57*4)+(500/'z')-(0.124*102);
       System.out.println("The value of double     : "+d);
       System.out.println("The value of float      : "+f);
       System.out.println("The value of long       : "+l);
       System.out.println("The value of int        : "+i);
       System.out.println("The value of short      : "+s);
       System.out.println("The value of byte       : "+b);

   }
}
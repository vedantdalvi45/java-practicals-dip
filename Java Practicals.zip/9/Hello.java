 class Hello {
    public static void main(String[] args) {
        double d = 99.0d;
        byte b = (byte)d;
        System.out.println("The value of double d is "+d);
        System.out.println("The value of byte b after Explicit typecasting  is "+b);
    }
}

class Tc{
    public static void main(String[] args) {
        byte b = 99;
        double d = b;
        System.out.println("byte = "+b);
        System.out.println("double = "+d);
    }
}
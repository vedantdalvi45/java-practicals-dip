class Typec{
    public static void main(String[] args) {
        byte c = 10;
        short s = c;
        int i = s;
        long l = i;
        float f = l;
        double d = f;
        System.out.println("byte : "+c);
        System.out.println("short : "+s);
        System.out.println("int : "+i);
        System.out.println("long : "+l);
        System.out.println("float : "+f);
        System.out.println("double : "+d);

    }
}
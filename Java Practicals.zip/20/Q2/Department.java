package MyInstitute.Department;

public class Department {
    public void staff(){
        System.out.println("Staff Members are about 50");
    }
}

package MyInstitute.M1;
import MyInstitute.Department.Department;
class M1 {
    public static void main(String[] args) {
        Department d = new Department();
        d.staff();
    }
}

import java.applet.*;  
import java.awt.Graphics;  
public class Hello extends Applet{  
  
public void paint(Graphics g){  
g.drawString("Welcome to the World of Applet",150,150);  

}  
  
}  
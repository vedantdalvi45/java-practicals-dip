public class while_1_to_50 {
    public static void main(String[] args) {
        int a=1;
        do {
            System.out.println(a);
            a++;
        } while (a<=50);
    }
}

public class StrCon {
    public static void main(String[] args) {
        String  s = args[0];
        System.out.println("The String Vlue is : "+s);
        Integer i = Integer.parseInt(s);
        System.out.println("Converted Integer value is :"+i);
    }
}

class Do_wh{
    public static void main(String[] args) {
        int i=1,j=1;
        do{
            System.out.println(i+" "+j);
            i++;
            j++;
        }while(i<=4||i<=3);
    }
}
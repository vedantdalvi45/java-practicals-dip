class Logic {
    public static void main(String[] args) {
        System.out.println((5<3)||(4<5));
        System.out.println((5<3)||(4>5));
    }
}